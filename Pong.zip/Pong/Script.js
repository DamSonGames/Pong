keyboardJS.bind("w", function(e){
  up1 = 1
}, function(e){
  up1 = 0
})

keyboardJS.bind("s", function(e){
  down1 = 1
}, function(e){
  down1 = 0
})

keyboardJS.bind("up", function(e){
  up2 = 1
}, function(e){
  up2 = 0
})

keyboardJS.bind("down", function(e){
  down2 = 1
}, function(e){
  down2 = 0
})

keyboardJS.bind("1", function(e){
  AI(1)
})

keyboardJS.bind("2", function(e){
  AI(2)
})

keyboardJS.bind("r", function(e){
  random = Math.random()
  random < 0.5 ? randomchoice = 1 : randomchoice = 2
  Restart(randomchoice)
})

keyboardJS.bind("r + shift", function(e){
  random = Math.random()
  random < 0.5 ? randomchoice = 1 : randomchoice = 2
  Restart(randomchoice)
  scores = [0, 0, 0]
})

var canvas = document.getElementById('canvas')
var context = canvas.getContext('2d')

context.canvas.width = window.innerWidth
context.canvas.height = window.innerHeight

var random = Math.random()
random < 0.5 ? randomchoice = 1 : randomchoice = 2
Restart(randomchoice)
var up1 = 0
var down1 = 0
var up2 = 0
var down2 = 0
var scores = [0, 0, 0]
var ai = [0, 0, 0]
var aicolor = [0, '#ffffff', '#ffffff']

function Move(){
  if(ai[1] === 0){
    if(up1 === 1){
      if(pos1 > 10){
        pos1 -= 4
      }
    }
    if(down1 === 1){
      if(pos1 < (window.innerHeight - 110)){
        pos1 += 4
      }
    }
  }else if(ai[1] === 1){
    if(ypos - 50 > pos1){
      if(pos1 < (window.innerHeight - 110)){
        pos1 += 4
      }
    }else if(ypos - 50 < pos1){
      if(pos1 > 10){
        pos1 -= 4
      }
    }
  }
  if(ai[2] === 0){
    if(up2 === 1){
      if(pos2 > 10){
        pos2 -= 4
      }
    }
    if(down2 === 1){
      if(pos2 < (window.innerHeight - 110)){
        pos2 += 4
      }
    }
  }else if(ai[2] === 1){
    if(ypos - 50 > pos2){
      if(pos2 < (window.innerHeight - 110)){
        pos2 += 4
      }
    }else if(ypos - 50 < pos2){
      if(pos2 > 10){
        pos2 -= 4
      }
    }
  }
}

function MoveBall(){
  xpos += Math.sin(direction*Math.PI) * 10
  ypos += Math.cos(direction*Math.PI) * 10

  if(ypos <= 10 || ypos >= window.innerHeight - 10){
    direction = (1 - direction)
  }
  if(xpos <= 100 && xpos >= 89 && ypos >= pos1 - 10 && ypos <= pos1 + 110){
    var dirchange = ((pos1 + 50) - ypos) / 300
    direction = (1 - direction) + (1 + dirchange)
  }
  if((xpos >= window.innerWidth - 100 && xpos <= window.innerWidth - 89 && ypos >= pos2 - 10 && ypos <= pos2 + 110)){
    var dirchange = ((pos2 + 50) - ypos) / 300
    direction = (1 - direction) - (1 + dirchange)
  }
  if(xpos < 0){
    scores[2] += 1
    Restart(2)
  }
  if(xpos > window.innerWidth){
    scores[1] += 1
    Restart(1)
  }
}

function Restart(player){
  window.xpos = window.innerWidth/2
  window.ypos = window.innerHeight/2
  player === 1 ? direction = 0.5 : direction = 1.5
  window.pos1 = window.innerHeight/2 - 50
  window.pos2 = window.innerHeight/2 - 50
}

function AI(player){
  if(ai[player] === 0){
    ai[player] = 1
    aicolor[player] = '#ff0000'
  }else if(ai[player] === 1){
    ai[player] = 0
    aicolor[player] = '#ffffff'
  }
}

function Render(){
  requestAnimationFrame(Render)
  
  Move()

  MoveBall()

  context.beginPath()
  context.rect(0, 0, window.innerWidth, window.innerHeight)
  context.fillStyle = "black"
  context.fill()

  context.beginPath()
  context.moveTo(80, pos1)
  context.lineTo(80, pos1 + 100)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(window.innerWidth/2, 0)
  context.lineTo(window.innerWidth/2, window.innerHeight)
  context.lineWidth = 1
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(xpos, ypos)
  context.lineTo(xpos, ypos)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(window.innerWidth - 80, pos2)
  context.lineTo(window.innerWidth - 80, pos2 + 100)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.font = 'normal 40pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText(scores[1], window.innerWidth/2 - (((scores[1].toString()).length * 30) + 10), 50)

  context.font = 'normal 40pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText(scores[2], window.innerWidth/2 + 10, 50)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText("R to replay", window.innerWidth/2 + 10, window.innerHeight - 20)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText("Shift + R to restart", window.innerWidth/2 - 210, window.innerHeight - 20)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = aicolor[2]
  context.fillText("AI", window.innerWidth/2 + 10, window.innerHeight - 50)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = aicolor[1]
  context.fillText("AI", window.innerWidth/2 - 40, window.innerHeight - 50)
}

Render()