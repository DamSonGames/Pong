keyboardJS.bind("w", function(e){
  up1 = 1
}, function(e){
  up1 = 0
})

keyboardJS.bind("s", function(e){
  down1 = 1
}, function(e){
  down1 = 0
})

keyboardJS.bind("up", function(e){
  up2 = 1
}, function(e){
  up2 = 0
})

keyboardJS.bind("down", function(e){
  down2 = 1
}, function(e){
  down2 = 0
})

keyboardJS.bind("1", function(e){
  AI(1)
})

keyboardJS.bind("2", function(e){
  AI(2)
})

keyboardJS.bind("r", function(e){
  random = Math.random()
  random < 0.5 ? randomchoice = 1 : randomchoice = 2
  Restart(randomchoice)
})

keyboardJS.bind("r + shift", function(e){
  random = Math.random()
  random < 0.5 ? randomchoice = 1 : randomchoice = 2
  Restart(randomchoice)
  scores = [0, 0, 0]
})

var canvas = document.getElementById('canvas')
var context = canvas.getContext('2d')

context.canvas.width = window.innerWidth
context.canvas.height = window.innerHeight

var pos1 = window.innerHeight/2 - 50
var pos2 = window.innerHeight/2 - 50
var xpos = window.innerWidth/2
var ypos = window.innerHeight/2
var random = Math.random()
var randomchoice = 0.5
random < 0.5 ? randomchoice = 0.5 : randomchoice = 1.5
var direction = randomchoice
var up1 = 0
var down1 = 0
var up2 = 0
var down2 = 0
var scores = [0, 0, 0]
var scoreleft = 1
var ai = [0, 0, 0]
var ai1color = '#ffffff'
var ai2color = '#ffffff'

function Move(){
  if(ai[1] === 0){
    if(up1 === 1){
      if(pos1 > 10){
        pos1 -= 4
      }
    }
    if(down1 === 1){
      if(pos1 < (window.innerHeight - 110)){
        pos1 += 4
      }
    }
  }else if(ai[1] === 1){
    if(ypos - 50 > pos1){
      if(pos1 < (window.innerHeight - 110)){
        pos1 += 4
      }
    }else if(ypos - 50 < pos1){
      if(pos1 > 10){
        pos1 -= 4
      }
    }
  }
  if(ai[2] === 0){
    if(up2 === 1){
      if(pos2 > 10){
        pos2 -= 4
      }
    }
    if(down2 === 1){
      if(pos2 < (window.innerHeight - 110)){
        pos2 += 4
      }
    }
  }else if(ai[2] === 1){
    if(ypos - 50 > pos2){
      if(pos2 < (window.innerHeight - 110)){
        pos2 += 4
      }
    }else if(ypos - 50 < pos2){
      if(pos2 > 10){
        pos2 -= 4
      }
    }
  }
}

function MoveBall(){
  xpos += Math.sin(direction*Math.PI) * 10
  ypos += Math.cos(direction*Math.PI) * 10

  if(ypos <= 10 || ypos >= window.innerHeight - 10){
    direction = (1 - direction)
  }
  if(xpos <= 100 && xpos >= 80 && ypos >= pos1 - 10 && ypos <= pos1 + 110){
    var dirchange = ((pos1 + 50) - ypos) / 300
    direction = (1 - direction) + (1 + dirchange)
  }
  if((xpos >= window.innerWidth - 100 && xpos <= window.innerWidth - 80 && ypos >= pos2 - 10 && ypos <= pos2 + 110)){
    var dirchange = ((pos2 + 50) - ypos) / 300
    direction = (1 - direction) - (1 + dirchange)
  }
  if(xpos < 0){
    Win(2)
  }
  if(xpos > window.innerWidth){
    Win(1)
  }
}

function Win(player){
  scores[player] += 1
  Restart(player)
}

function Restart(player){
  xpos = window.innerWidth/2
  ypos = window.innerHeight/2
  player === 1 ? direction = 0.5 : direction = 1.5
  pos1 = window.innerHeight/2 - 50
  pos2 = window.innerHeight/2 - 50
}

function AI(player){
  if(player === 1){
    if(ai[1] === 0){
      ai[1] = 1
      ai1color = '#ff0000'
    }else if(ai[1] === 1){
      ai[1] = 0
      ai1color = '#ffffff'
    }
  }
  if(player === 2){
    if(ai[2] === 0){
      ai[2] = 1
      ai2color = '#ff0000'
    }else if(ai[2] === 1){
      ai[2] = 0
      ai2color = '#ffffff'
    }
  }
}

function Render(){
  requestAnimationFrame(Render)
  
  Move()

  MoveBall()

  context.beginPath()
  context.rect(0, 0, window.innerWidth, window.innerHeight)
  context.fillStyle = "black"
  context.fill()

  context.beginPath()
  context.moveTo(80, pos1)
  context.lineTo(80, pos1 + 100)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(window.innerWidth/2, 0)
  context.lineTo(window.innerWidth/2, window.innerHeight)
  context.lineWidth = 1
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(xpos, ypos)
  context.lineTo(xpos, ypos)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  context.beginPath()
  context.moveTo(window.innerWidth - 80, pos2)
  context.lineTo(window.innerWidth - 80, pos2 + 100)
  context.lineWidth = 20
  context.strokeStyle = '#ffffff'
  context.lineCap = 'round'
  context.stroke()

  var scorelength = scores[1].toString()

  context.font = 'normal 40pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText(scores[1], window.innerWidth/2 - ((scorelength.length * 30) + 10), 50)

  context.font = 'normal 40pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText(scores[2], window.innerWidth/2 + 10, 50)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText("R to replay", window.innerWidth/2 + 10, window.innerHeight - 20)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = '#ffffff'
  context.fillText("Shift + R to restart", window.innerWidth/2 - 210, window.innerHeight - 20)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = ai2color
  context.fillText("AI", window.innerWidth/2 + 10, window.innerHeight - 50)

  context.font = 'normal 20pt Lucida Console'
  context.fillStyle = ai1color
  context.fillText("AI", window.innerWidth/2 - 40, window.innerHeight - 50)
}

Render()